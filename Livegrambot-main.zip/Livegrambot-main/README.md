# Livegrambot

Please change BOT_TOKEN and ADMINS values in ./data/config.py


### Commands

/start - start conversation.
/ban - ban user.
/unban - unban user.


This bot language is Uzbek.
