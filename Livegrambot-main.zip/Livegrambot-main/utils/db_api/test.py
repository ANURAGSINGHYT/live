import datetime
prev = datetime.datetime.today()
prev_date = prev.strftime("%Y-%m-%d")

print(prev_date)